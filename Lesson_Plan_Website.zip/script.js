
function generatePlan() {
  let subject = document.getElementById('subject').value;
  let level = document.getElementById('level').value;
  let topic = document.getElementById('topic').value;
  let duration = document.getElementById('duration').value;

  let plan = `LESSON PLAN
Subject: ${subject}
Class: ${level}
Topic: ${topic}
Duration: ${duration}

Objectives:
- Understand key concepts
- Apply knowledge

Activities:
- Introduction
- Teaching
- Practice

Assessment:
- Questions
- Exercises`;

  document.getElementById('output').textContent = plan;
}
